/*
 * The contents of this file are subject to the Interbase Public
 * License Version 1.0 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy
 * of the License at http://www.Inprise.com/IPL.html
 *
 * Software distributed under the License is distributed on an
 * "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either express
 * or implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code was created by Inprise Corporation
 * and its predecessors. Portions created by Inprise Corporation are
 * Copyright (C) Inprise Corporation.
 *
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */
1, 2, 9, 14, 0, 'Q', 'L', 'I', '$', 'P', 'R', 'O', 'C', 'E',
'D', 'U', 'R', 'E', 'S', 55, 2, 0, 2, 0, 3, 6, 18, 0, 'Q', 'L',
'I', '$', 'P', 'R', 'O', 'C', 'E', 'D', 'U', 'R', 'E', '_', 'N',
'A', 'M', 'E', 55, 2, 0, 2, 0, 'F', 2, 0, 14, 0, 'G', 2, 0, 31,
0, 3, 7, 18, 0, 'Q', 'L', 'I', '$', 'P', 'R', 'O', 'C', 'E',
'D', 'U', 'R', 'E', '_', 'N', 'A', 'M', 'E', 50, 14, 0, 'Q',
'L', 'I', '$', 'P', 'R', 'O', 'C', 'E', 'D', 'U', 'R', 'E', 'S',
55, 2, 0, 2, 0, 92, 2, 0, 0, 0, 3, 6, 13, 0, 'Q', 'L', 'I', '$',
'P', 'R', 'O', 'C', 'E', 'D', 'U', 'R', 'E', 55, 2, 0, 2, 0,
'F', 2, 0, 5, 1, 'I', 2, 0, 1, 0, 'J', 2, 0, 'P', 0, 3, 7, 13,
0, 'Q', 'L', 'I', '$', 'P', 'R', 'O', 'C', 'E', 'D', 'U', 'R',
'E', 50, 14, 0, 'Q', 'L', 'I', '$', 'P', 'R', 'O', 'C', 'E',
'D', 'U', 'R', 'E', 'S', 55, 2, 0, 2, 0, 92, 2, 0, 1, 0, 3, 3,
255,
