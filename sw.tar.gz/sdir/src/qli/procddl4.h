/*
 * The contents of this file are subject to the Interbase Public
 * License Version 1.0 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy
 * of the License at http://www.Inprise.com/IPL.html
 *
 * Software distributed under the License is distributed on an
 * "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either express
 * or implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code was created by Inprise Corporation
 * and its predecessors. Portions created by Inprise Corporation are
 * Copyright (C) Inprise Corporation.
 *
 * All Rights Reserved.
 * Contributor(s): ______________________________________.
 */
    isc_dyn_version_1,
       isc_dyn_begin,
          isc_dyn_def_idx, 19,0, 'Q','L','I','$','P','R','O','C','E','D','U','R','E','S','_','I','D','X','1',
             isc_dyn_rel_name, 14,0, 'Q','L','I','$','P','R','O','C','E','D','U','R','E','S',
             isc_dyn_idx_unique, 2,0, 1,0,
             isc_dyn_idx_inactive, 2,0, 0,0,
             isc_dyn_fld_name, 18,0, 'Q','L','I','$','P','R','O','C','E','D','U','R','E','_','N','A','M','E',
             isc_dyn_end,
          isc_dyn_end,
    isc_dyn_eoc
